const database = require('../database.js')

const filmes = async (req, res) => {
    // Rodar um SELECT na tabela de PRODUTOS
    const resultado = await database.query('SELECT * FROM filmes')
    res.status(200).send({ mensagem: resultado.rows })
}
const categoria = async (req, res) => {
    const categoria = req.params.categoria
    // Rodar um SELECT na tabela de PRODUTOS
    const resultado = await database.query(`SELECT * FROM filmes where categoria = '${categoria}'`)
    res.status(200).send({ resultado: resultado.rows })
}
const cadastrarFilme = async (req, res) => {
    const titulo = req.body.titulo
    const categoria = req.body.categoria
    // Rodar um SELECT na tabela de PRODUTOS
    const resultado = await database.query(`INSERT INTO filmes (titulo, categoria)VALUES ('${titulo}', '${categoria}');`)
    res.status(201).send({ mensagem: resultado.rows })
}
const alterarId = async (req, res) => {
    const id = req.params.id
    const titulo = req.body.titulo
    const categoria = req.body.categoria
    // Rodar um SELECT na tabela de PRODUTOS
    const resultado = await database.query(`UPDATE filmes SET titulo = '${titulo}', categoria = '${categoria}' WHERE id = ${id};`)
    res.status(201).send({ mensagem: resultado.rows })
}
const deletar = async (req, res) => {
    const id = Number(req.params.id)
    // Rodar um SELECT na tabela de PRODUTOS
    const resultado = await database.query(`DELETE FROM filmes WHERE id = '${id}'`)
    res.status(201).send({ mensagem: resultado.rows })
}


// Exportar diversas variaveis
module.exports = { filmes, categoria, cadastrarFilme, alterarId, deletar }